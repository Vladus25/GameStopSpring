package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.GiocoEntity;

public interface GiocoRepository extends JpaRepository<GiocoEntity, Integer>{

}
