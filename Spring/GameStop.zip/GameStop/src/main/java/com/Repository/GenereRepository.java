package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.GenereEntity;

public interface GenereRepository extends JpaRepository<GenereEntity, Integer>{
	
}
