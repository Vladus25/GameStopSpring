package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.AccessorioEntity;

public interface AccessorioRepository extends JpaRepository<AccessorioEntity, Integer> {

}
