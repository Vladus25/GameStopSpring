package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.SedeEntity;

public interface SedeRepository extends JpaRepository<SedeEntity, Integer>{

}
