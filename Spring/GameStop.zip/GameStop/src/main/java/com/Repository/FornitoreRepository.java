package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.FornitoreEntity;

public interface FornitoreRepository extends JpaRepository<FornitoreEntity, Integer>{

}
