package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.ProdottoEntity;

public interface ProdottoRepository extends JpaRepository<ProdottoEntity, Integer>{

}
