package com.Entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "gioco")
public class GiocoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "n_giocatori")
    private Integer numeroGiocatori;

    private String nome;

    @ManyToMany
    @JoinTable(
        name = "gioco_accessorio",
        joinColumns = @JoinColumn(name = "id_gioco"),
        inverseJoinColumns = @JoinColumn(name = "id_accessorio")
    )
    private Set<AccessorioEntity> accessori;
    
    @ManyToMany
    @JoinTable(
        name = "gioco_console",
        joinColumns = @JoinColumn(name = "id_gioco"),
        inverseJoinColumns = @JoinColumn(name = "id_console")
    )
    private Set<ConsoleEntity> console;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getNumeroGiocatori() {
		return numeroGiocatori;
	}

	public void setNumeroGiocatori(Integer numeroGiocatori) {
		this.numeroGiocatori = numeroGiocatori;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<AccessorioEntity> getAccessori() {
		return accessori;
	}

	public void setAccessori(Set<AccessorioEntity> accessori) {
		this.accessori = accessori;
	}

	public Set<ConsoleEntity> getConsole() {
		return console;
	}

	public void setConsole(Set<ConsoleEntity> console) {
		this.console = console;
	}

	public GiocoEntity(Integer id, Integer numeroGiocatori, String nome, Set<AccessorioEntity> accessori,
			Set<ConsoleEntity> console) {
		super();
		this.id = id;
		this.numeroGiocatori = numeroGiocatori;
		this.nome = nome;
		this.accessori = accessori;
		this.console = console;
	}
    
    
}
