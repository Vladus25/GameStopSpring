package com.Entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "genere")
public class GenereEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nome;

    @ManyToMany
    @JoinTable(
        name = "genere_gioco",
        joinColumns = @JoinColumn(name = "id_genere"),
        inverseJoinColumns = @JoinColumn(name = "id_gioco")
    )
    private Set<GiocoEntity> giochi;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<GiocoEntity> getGiochi() {
		return giochi;
	}

	public void setGiochi(Set<GiocoEntity> giochi) {
		this.giochi = giochi;
	}

	public GenereEntity(Integer id, String nome, Set<GiocoEntity> giochi) {
		super();
		this.id = id;
		this.nome = nome;
		this.giochi = giochi;
	}
    
    
}
