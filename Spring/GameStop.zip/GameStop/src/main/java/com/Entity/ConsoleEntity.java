package com.Entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "console")
public class ConsoleEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private boolean portatile;

    @Column(name = "n_giocatori")
    private Integer numeroGiocatori;

    private Integer memoria;

    @ManyToMany
    @JoinTable(
        name = "console_accessorio",
        joinColumns = @JoinColumn(name = "id_console"),
        inverseJoinColumns = @JoinColumn(name = "id_accessorio")
    )
    private Set<AccessorioEntity> accessori;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean isPortatile() {
		return portatile;
	}

	public void setPortatile(boolean portatile) {
		this.portatile = portatile;
	}

	public Integer getNumeroGiocatori() {
		return numeroGiocatori;
	}

	public void setNumeroGiocatori(Integer numeroGiocatori) {
		this.numeroGiocatori = numeroGiocatori;
	}

	public Integer getMemoria() {
		return memoria;
	}

	public void setMemoria(Integer memoria) {
		this.memoria = memoria;
	}

	public Set<AccessorioEntity> getAccessori() {
		return accessori;
	}

	public void setAccessori(Set<AccessorioEntity> accessori) {
		this.accessori = accessori;
	}

	public ConsoleEntity(Integer id, boolean portatile, Integer numeroGiocatori, Integer memoria,
			Set<AccessorioEntity> accessori) {
		super();
		this.id = id;
		this.portatile = portatile;
		this.numeroGiocatori = numeroGiocatori;
		this.memoria = memoria;
		this.accessori = accessori;
	}
    
    
}

