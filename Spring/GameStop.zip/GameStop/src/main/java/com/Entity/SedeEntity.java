package com.Entity;

import javax.persistence.*;

@Entity
@Table(name = "sede")
public class SedeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String indirizzo;

    private String citaa;

    @ManyToOne
    @JoinColumn(name = "id_casaproduttrice")
    private CasaproduttriceEntity casaProduttrice;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getCitaa() {
		return citaa;
	}

	public void setCitaa(String citaa) {
		this.citaa = citaa;
	}

	public CasaproduttriceEntity getCasaProduttrice() {
		return casaProduttrice;
	}

	public void setCasaProduttrice(CasaproduttriceEntity casaProduttrice) {
		this.casaProduttrice = casaProduttrice;
	}

	public SedeEntity(Integer id, String indirizzo, String citaa, CasaproduttriceEntity casaProduttrice) {
		super();
		this.id = id;
		this.indirizzo = indirizzo;
		this.citaa = citaa;
		this.casaProduttrice = casaProduttrice;
	}
    
    

    
}

