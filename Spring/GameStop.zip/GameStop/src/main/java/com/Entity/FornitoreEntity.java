package com.Entity;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "fornitore")
public class FornitoreEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nome;

    @ManyToMany
    @JoinTable(
        name = "fornitore_casaproduttrice",
        joinColumns = @JoinColumn(name = "fornitore_id"),
        inverseJoinColumns = @JoinColumn(name = "casaproduttrice_id")
    )
    private Set<CasaproduttriceEntity> casaProduttrici;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<CasaproduttriceEntity> getCasaProduttrici() {
		return casaProduttrici;
	}

	public void setCasaProduttrici(Set<CasaproduttriceEntity> casaProduttrici) {
		this.casaProduttrici = casaProduttrici;
	}

	public FornitoreEntity(Integer id, String nome, Set<CasaproduttriceEntity> casaProduttrici) {
		super();
		this.id = id;
		this.nome = nome;
		this.casaProduttrici = casaProduttrici;
	}
    
    	
}

