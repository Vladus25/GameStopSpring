package com.Entity;

import javax.persistence.*;

@Entity
@Table(name = "prodotto")
public class ProdottoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    private String nome;

    private String descrizione;

    private Integer prezzo;
    
    @Column(name = "anno_rilascio")
    private String annoRilascio;
    
    @ManyToOne
    @JoinColumn(name = "id_casaproduttrice")
    private CasaproduttriceEntity casaProduttrice;

    @ManyToOne
    @JoinColumn(name = "id_fornitore")
    private FornitoreEntity fornitore;

    @ManyToOne
    @JoinColumn(name = "id_cliente")
    private ClienteEntity cliente;

    @ManyToOne
    @JoinColumn(name = "id_gioco")
    private GiocoEntity gioco;

    @ManyToOne
    @JoinColumn(name = "id_console")
    private ConsoleEntity console;

    @ManyToOne
    @JoinColumn(name = "id_accessorio")
    private AccessorioEntity accessorio;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Integer getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(Integer prezzo) {
		this.prezzo = prezzo;
	}

	public String getAnnoRilascio() {
		return annoRilascio;
	}

	public void setAnnoRilascio(String annoRilascio) {
		this.annoRilascio = annoRilascio;
	}

	public CasaproduttriceEntity getCasaProduttrice() {
		return casaProduttrice;
	}

	public void setCasaProduttrice(CasaproduttriceEntity casaProduttrice) {
		this.casaProduttrice = casaProduttrice;
	}

	public FornitoreEntity getFornitore() {
		return fornitore;
	}

	public void setFornitore(FornitoreEntity fornitore) {
		this.fornitore = fornitore;
	}

	public ClienteEntity getCliente() {
		return cliente;
	}

	public void setCliente(ClienteEntity cliente) {
		this.cliente = cliente;
	}

	public GiocoEntity getGioco() {
		return gioco;
	}

	public void setGioco(GiocoEntity gioco) {
		this.gioco = gioco;
	}

	public ConsoleEntity getConsole() {
		return console;
	}

	public void setConsole(ConsoleEntity console) {
		this.console = console;
	}

	public AccessorioEntity getAccessorio() {
		return accessorio;
	}

	public void setAccessorio(AccessorioEntity accessorio) {
		this.accessorio = accessorio;
	}

	public ProdottoEntity(Integer id, String nome, String descrizione, Integer prezzo, String annoRilascio,
			CasaproduttriceEntity casaProduttrice, FornitoreEntity fornitore, ClienteEntity cliente, GiocoEntity gioco,
			ConsoleEntity console, AccessorioEntity accessorio) {
		super();
		this.id = id;
		this.nome = nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
		this.annoRilascio = annoRilascio;
		this.casaProduttrice = casaProduttrice;
		this.fornitore = fornitore;
		this.cliente = cliente;
		this.gioco = gioco;
		this.console = console;
		this.accessorio = accessorio;
	}

    
}
